import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6f716b03"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=6f716b03"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=6f716b03"; const useState = __vite__cjsImport4_react["useState"];
const Blog = ({
  user,
  blog,
  updateBlogs,
  deleteBlog
}) => {
  _s();
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const [view, setView] = useState(true);
  const ToggleView = () => {
    console.log(blog);
    setView(!view);
    console.log(blog.user.username);
  };
  const addLike = () => {
    const updatedBlog = {
      ...blog,
      likes: blog.likes + 1
    };
    updateBlogs(updatedBlog, blog.id);
  };
  const removeBlog = () => {
    if (window.confirm(`Remove blog ${blog.title} by ${blog.author}`))
      deleteBlog(blog.id);
    console.log("lol");
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-testid": "blog", style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { "data-testid": "title", children: blog.title }, void 0, false, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    "  ",
    blog.author,
    /* @__PURE__ */ jsxDEV("button", { className: "view", onClick: ToggleView, children: view ? "view" : "hide" }, void 0, false, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 36,
      columnNumber: 65
    }, this),
    !view && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: blog.url }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { "data-testid": "number", children: blog.likes }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 39,
          columnNumber: 14
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: addLike, children: "like" }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 39,
          columnNumber: 54
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 39,
        columnNumber: 9
      }, this),
      blog.user !== void 0 ? /* @__PURE__ */ jsxDEV("p", { children: blog.user.username }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 40,
        columnNumber: 36
      }, this) : "",
      user.username === blog.user.username ? /* @__PURE__ */ jsxDEV("button", { onClick: removeBlog, children: "remove" }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 41,
        columnNumber: 49
      }, this) : ""
    ] }, void 0, true, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 37,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
};
_s(Blog, "0GwXS2AbgYXOnReBpYp2uIf1rGQ=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.object.isRequired,
  updateBlogs: PropTypes.func.isRequired,
  deleteBlog: PropTypes.func.isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNNOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5DTixPQUFPQSxlQUFlO0FBQ3RCLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBYUM7QUFBVyxNQUFNO0FBQUFDLEtBQUE7QUFDeEQsUUFBTUMsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2hCO0FBQ0EsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlkLFNBQVMsSUFBSTtBQUVyQyxRQUFNZSxhQUFhQSxNQUFNO0FBQ3ZCQyxZQUFRQyxJQUFJZCxJQUFJO0FBQ2hCVyxZQUFRLENBQUNELElBQUk7QUFDYkcsWUFBUUMsSUFBSWQsS0FBS0QsS0FBS2dCLFFBQVE7QUFBQSxFQUNoQztBQUVBLFFBQU1DLFVBQVVBLE1BQU07QUFDcEIsVUFBTUMsY0FBYztBQUFBLE1BQ2xCLEdBQUdqQjtBQUFBQSxNQUNIa0IsT0FBT2xCLEtBQUtrQixRQUFRO0FBQUEsSUFDdEI7QUFDQWpCLGdCQUFZZ0IsYUFBYWpCLEtBQUttQixFQUFFO0FBQUEsRUFDbEM7QUFFQSxRQUFNQyxhQUFhQSxNQUFNO0FBQ3ZCLFFBQUlDLE9BQU9DLFFBQVMsZUFBY3RCLEtBQUt1QixLQUFNLE9BQU12QixLQUFLd0IsTUFBTyxFQUFDO0FBQzlEdEIsaUJBQVdGLEtBQUttQixFQUFFO0FBQ3BCTixZQUFRQyxJQUFJLEtBQUs7QUFBQSxFQUNuQjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxlQUFZLFFBQU8sT0FBT1YsV0FDN0I7QUFBQSwyQkFBQyxTQUFJLGVBQVksU0FBU0osZUFBS3VCLFNBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUM7QUFBQSxJQUFNO0FBQUEsSUFBR3ZCLEtBQUt3QjtBQUFBQSxJQUFPLHVCQUFDLFlBQU8sV0FBVSxRQUFPLFNBQVNaLFlBQWFGLGlCQUFPLFNBQVMsVUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRTtBQUFBLElBQy9ILENBQUNBLFFBQVEsdUJBQUMsU0FDVDtBQUFBLDZCQUFDLE9BQUdWLGVBQUt5QixPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYTtBQUFBLE1BQ2IsdUJBQUMsU0FBSTtBQUFBLCtCQUFDLE9BQUUsZUFBWSxVQUFVekIsZUFBS2tCLFNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUFJLHVCQUFDLFlBQU8sU0FBU0YsU0FBUyxvQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFdBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Y7QUFBQSxNQUNuRmhCLEtBQUtELFNBQU8yQixTQUFZLHVCQUFDLE9BQUcxQixlQUFLRCxLQUFLZ0IsWUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVCLElBQU87QUFBQSxNQUN0RGhCLEtBQUtnQixhQUFXZixLQUFLRCxLQUFLZ0IsV0FBVyx1QkFBQyxZQUFPLFNBQVNLLFlBQVksc0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUMsSUFBWTtBQUFBLFNBSjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLVjtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQ2pCLEdBekNLTCxNQUFJO0FBQUE2QixLQUFKN0I7QUEyQ05BLEtBQUs4QixZQUFZO0FBQUEsRUFDZjVCLE1BQU1KLFVBQVVpQyxPQUFPQztBQUFBQSxFQUN2QjdCLGFBQWFMLFVBQVVtQyxLQUFLRDtBQUFBQSxFQUM1QjVCLFlBQVlOLFVBQVVtQyxLQUFLRDtBQUM3QjtBQUVBLGVBQWVoQztBQUFJLElBQUE2QjtBQUFBSyxhQUFBTCxJQUFBIiwibmFtZXMiOlsiUHJvcFR5cGVzIiwidXNlU3RhdGUiLCJCbG9nIiwidXNlciIsImJsb2ciLCJ1cGRhdGVCbG9ncyIsImRlbGV0ZUJsb2ciLCJfcyIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwidmlldyIsInNldFZpZXciLCJUb2dnbGVWaWV3IiwiY29uc29sZSIsImxvZyIsInVzZXJuYW1lIiwiYWRkTGlrZSIsInVwZGF0ZWRCbG9nIiwibGlrZXMiLCJpZCIsInJlbW92ZUJsb2ciLCJ3aW5kb3ciLCJjb25maXJtIiwidGl0bGUiLCJhdXRob3IiLCJ1cmwiLCJ1bmRlZmluZWQiLCJfYyIsInByb3BUeXBlcyIsIm9iamVjdCIsImlzUmVxdWlyZWQiLCJmdW5jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJ1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgQmxvZyA9ICh7IHVzZXIsIGJsb2csIHVwZGF0ZUJsb2dzLCBkZWxldGVCbG9nIH0pID0+IHtcbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xuICAgIHBhZGRpbmdUb3A6IDEwLFxuICAgIHBhZGRpbmdMZWZ0OiAyLFxuICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBtYXJnaW5Cb3R0b206IDVcbiAgfVxuICBjb25zdCBbdmlldywgc2V0Vmlld10gPSB1c2VTdGF0ZSh0cnVlKVxuXG4gIGNvbnN0IFRvZ2dsZVZpZXcgPSAoKSA9PiB7XG4gICAgY29uc29sZS5sb2coYmxvZylcbiAgICBzZXRWaWV3KCF2aWV3KVxuICAgIGNvbnNvbGUubG9nKGJsb2cudXNlci51c2VybmFtZSlcbiAgfVxuXG4gIGNvbnN0IGFkZExpa2UgPSAoKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZEJsb2cgPSB7XG4gICAgICAuLi5ibG9nLFxuICAgICAgbGlrZXM6IGJsb2cubGlrZXMgKyAxXG4gICAgfVxuICAgIHVwZGF0ZUJsb2dzKHVwZGF0ZWRCbG9nLCBibG9nLmlkKVxuICB9XG5cbiAgY29uc3QgcmVtb3ZlQmxvZyA9ICgpID0+IHtcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYFJlbW92ZSBibG9nICR7YmxvZy50aXRsZX0gYnkgJHtibG9nLmF1dGhvcn1gKSlcbiAgICAgIGRlbGV0ZUJsb2coYmxvZy5pZClcbiAgICBjb25zb2xlLmxvZygnbG9sJylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBkYXRhLXRlc3RpZD1cImJsb2dcIiBzdHlsZT17YmxvZ1N0eWxlfT5cbiAgICAgIDxkaXYgZGF0YS10ZXN0aWQ9XCJ0aXRsZVwiPntibG9nLnRpdGxlfTwvZGl2PiAge2Jsb2cuYXV0aG9yfTxidXR0b24gY2xhc3NOYW1lPVwidmlld1wiIG9uQ2xpY2s9e1RvZ2dsZVZpZXd9Pnt2aWV3ID8gJ3ZpZXcnIDogJ2hpZGUnfTwvYnV0dG9uPlxuICAgICAgeyF2aWV3ICYmIDxkaXY+XG4gICAgICAgIDxwPntibG9nLnVybH08L3A+XG4gICAgICAgIDxkaXY+PHAgZGF0YS10ZXN0aWQ9J251bWJlcic+e2Jsb2cubGlrZXN9PC9wPjxidXR0b24gb25DbGljaz17YWRkTGlrZX0+bGlrZTwvYnV0dG9uPjwvZGl2PlxuICAgICAgICB7YmxvZy51c2VyIT09dW5kZWZpbmVkID8gPHA+e2Jsb2cudXNlci51c2VybmFtZX08L3A+IDogJyd9XG4gICAgICAgIHt1c2VyLnVzZXJuYW1lPT09YmxvZy51c2VyLnVzZXJuYW1lID8gPGJ1dHRvbiBvbkNsaWNrPXtyZW1vdmVCbG9nfT5yZW1vdmU8L2J1dHRvbj4gOiAnJ31cbiAgICAgIDwvZGl2Pn1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5CbG9nLnByb3BUeXBlcyA9IHtcbiAgYmxvZzogUHJvcFR5cGVzLm9iamVjdC5pc1JlcXVpcmVkLFxuICB1cGRhdGVCbG9nczogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgZGVsZXRlQmxvZzogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZFxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nIl0sImZpbGUiOiJDOi9Vc2Vycy9qdmhhci9GdWxsU3RhY2tPcGVuL29zYTUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==