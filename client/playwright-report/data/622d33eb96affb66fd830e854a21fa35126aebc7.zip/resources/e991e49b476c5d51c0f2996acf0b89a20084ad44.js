import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6f716b03"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6f716b03"; const useState = __vite__cjsImport3_react["useState"];
const Togglable = (props) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 17,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
        lineNumber: 22,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 19,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
};
_s(Togglable, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Togglable;
export default Togglable;
var _c;
$RefreshReg$(_c, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZlIsU0FBU0EsZ0JBQWdCO0FBRXpCLE1BQU1DLFlBQWFDLFdBQVU7QUFBQUMsS0FBQTtBQUMzQixRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSUwsU0FBUyxLQUFLO0FBRTVDLFFBQU1NLGtCQUFrQjtBQUFBLElBQUVDLFNBQVNILFVBQVUsU0FBUztBQUFBLEVBQUc7QUFDekQsUUFBTUksa0JBQWtCO0FBQUEsSUFBRUQsU0FBU0gsVUFBVSxLQUFLO0FBQUEsRUFBTztBQUV6RCxRQUFNSyxtQkFBbUJBLE1BQU07QUFDN0JKLGVBQVcsQ0FBQ0QsT0FBTztBQUFBLEVBQ3JCO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxPQUFPRSxpQkFDVixpQ0FBQyxZQUFPLFNBQVNHLGtCQUFtQlAsZ0JBQU1RLGVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0QsS0FEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLE9BQU9GLGlCQUVUTjtBQUFBQSxZQUFNUztBQUFBQSxNQUNQLHVCQUFDLFlBQU8sU0FBU0Ysa0JBQWtCLHNCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsU0FIM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFFSjtBQUFDTixHQXRCS0YsV0FBUztBQUFBVyxLQUFUWDtBQXdCTixlQUFlQTtBQUFTLElBQUFXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlRvZ2dsYWJsZSIsInByb3BzIiwiX3MiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJ0b2dnbGVWaXNpYmlsaXR5IiwiYnV0dG9uTGFiZWwiLCJjaGlsZHJlbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVG9nZ2xhYmxlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBUb2dnbGFibGUgPSAocHJvcHMpID0+IHtcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgaGlkZVdoZW5WaXNpYmxlID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJ25vbmUnIDogJycgfVxuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnJyA6ICdub25lJyB9XG5cbiAgY29uc3QgdG9nZ2xlVmlzaWJpbGl0eSA9ICgpID0+IHtcbiAgICBzZXRWaXNpYmxlKCF2aXNpYmxlKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBzdHlsZT17aGlkZVdoZW5WaXNpYmxlfT5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT57cHJvcHMuYnV0dG9uTGFiZWx9PC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9e3Nob3dXaGVuVmlzaWJsZX0+XG5cbiAgICAgICAge3Byb3BzLmNoaWxkcmVufVxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9PmNhbmNlbDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgVG9nZ2xhYmxlIl0sImZpbGUiOiJDOi9Vc2Vycy9qdmhhci9GdWxsU3RhY2tPcGVuL29zYTUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvVG9nZ2xhYmxlLmpzeCJ9