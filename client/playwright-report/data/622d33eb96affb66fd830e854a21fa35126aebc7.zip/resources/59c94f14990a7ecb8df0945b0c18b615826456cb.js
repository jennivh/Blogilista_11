import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AddBlog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6f716b03"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=6f716b03"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=6f716b03"; const useState = __vite__cjsImport4_react["useState"];
const AddBlog = ({
  submitNewBlog
}) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const addBlog = (e) => {
    e.preventDefault();
    const newBlog = {
      title,
      author,
      url
    };
    submitNewBlog(newBlog);
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "create new" }, void 0, false, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addBlog, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { children: "title:" }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
          lineNumber: 26,
          columnNumber: 14
        }, this),
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "title", type: "text", value: title, onChange: (e) => setTitle(e.target.value) }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
          lineNumber: 26,
          columnNumber: 35
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
        lineNumber: 26,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { children: "author:" }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
          lineNumber: 27,
          columnNumber: 14
        }, this),
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "author", type: "text", value: author, onChange: (e) => setAuthor(e.target.value) }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
          lineNumber: 27,
          columnNumber: 36
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
        lineNumber: 27,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { children: "url:" }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
          lineNumber: 28,
          columnNumber: 14
        }, this),
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "url", type: "text", value: url, onChange: (e) => setUrl(e.target.value) }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
          lineNumber: 28,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
        lineNumber: 29,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(AddBlog, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = AddBlog;
AddBlog.propTypes = {
  submitNewBlog: PropTypes.func.isRequired
};
export default AddBlog;
var _c;
$RefreshReg$(_c, "AddBlog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/components/AddBlog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5CTixPQUFPQSxlQUFlO0FBQ3RCLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxVQUFVQSxDQUFDO0FBQUEsRUFBRUM7QUFBYyxNQUFNO0FBQUFDLEtBQUE7QUFDckMsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlMLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNNLFFBQVFDLFNBQVMsSUFBSVAsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ1EsS0FBS0MsTUFBTSxJQUFJVCxTQUFTLEVBQUU7QUFFakMsUUFBTVUsVUFBV0MsT0FBTTtBQUNyQkEsTUFBRUMsZUFBZTtBQUNqQixVQUFNQyxVQUFVO0FBQUEsTUFBRVQ7QUFBQUEsTUFBT0U7QUFBQUEsTUFBUUU7QUFBQUEsSUFBSTtBQUNyQ04sa0JBQWNXLE9BQU87QUFDckJSLGFBQVMsRUFBRTtBQUNYRSxjQUFVLEVBQUU7QUFDWkUsV0FBTyxFQUFFO0FBQUEsRUFDWDtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBQUEsSUFDZCx1QkFBQyxVQUFLLFVBQVVDLFNBQ2Q7QUFBQSw2QkFBQyxTQUFJO0FBQUEsK0JBQUMsV0FBTSxzQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxRQUFRLHVCQUFDLFdBQU0sZUFBWSxTQUFRLE1BQUssUUFBTyxPQUFPTixPQUFPLFVBQVdPLE9BQU1OLFNBQVNNLEVBQUVHLE9BQU9DLEtBQUssS0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRjtBQUFBLFdBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEg7QUFBQSxNQUM1SCx1QkFBQyxTQUFJO0FBQUEsK0JBQUMsV0FBTSx1QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWM7QUFBQSxRQUFRLHVCQUFDLFdBQU0sZUFBWSxVQUFTLE1BQUssUUFBTyxPQUFPVCxRQUFRLFVBQVdLLE9BQU1KLFVBQVVJLEVBQUVHLE9BQU9DLEtBQUssS0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRztBQUFBLFdBQTdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0k7QUFBQSxNQUNoSSx1QkFBQyxTQUFJO0FBQUEsK0JBQUMsV0FBTSxvQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUFRLHVCQUFDLFdBQU0sZUFBWSxPQUFNLE1BQUssUUFBTyxPQUFPUCxLQUFLLFVBQVdHLE9BQU1GLE9BQU9FLEVBQUVHLE9BQU9DLEtBQUssS0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFdBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0g7QUFBQSxNQUNwSCx1QkFBQyxZQUFPLE1BQUssVUFBUyxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLFNBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQ1osR0F6QktGLFNBQU87QUFBQWUsS0FBUGY7QUEyQk5BLFFBQVFnQixZQUFZO0FBQUEsRUFDbEJmLGVBQWVILFVBQVVtQixLQUFLQztBQUNoQztBQUVBLGVBQWVsQjtBQUFPLElBQUFlO0FBQUFJLGFBQUFKLElBQUEiLCJuYW1lcyI6WyJQcm9wVHlwZXMiLCJ1c2VTdGF0ZSIsIkFkZEJsb2ciLCJzdWJtaXROZXdCbG9nIiwiX3MiLCJ0aXRsZSIsInNldFRpdGxlIiwiYXV0aG9yIiwic2V0QXV0aG9yIiwidXJsIiwic2V0VXJsIiwiYWRkQmxvZyIsImUiLCJwcmV2ZW50RGVmYXVsdCIsIm5ld0Jsb2ciLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwicHJvcFR5cGVzIiwiZnVuYyIsImlzUmVxdWlyZWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBZGRCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBBZGRCbG9nID0gKHsgc3VibWl0TmV3QmxvZyB9KSA9PiB7XG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFthdXRob3IsIHNldEF1dGhvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VybCwgc2V0VXJsXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGNvbnN0IGFkZEJsb2cgPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGNvbnN0IG5ld0Jsb2cgPSB7IHRpdGxlLCBhdXRob3IsIHVybCB9XG4gICAgc3VibWl0TmV3QmxvZyhuZXdCbG9nKVxuICAgIHNldFRpdGxlKCcnKVxuICAgIHNldEF1dGhvcignJylcbiAgICBzZXRVcmwoJycpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+Y3JlYXRlIG5ldzwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17YWRkQmxvZ30+XG4gICAgICAgIDxkaXY+PGxhYmVsPnRpdGxlOjwvbGFiZWw+PGlucHV0IGRhdGEtdGVzdGlkPSd0aXRsZScgdHlwZT1cInRleHRcIiB2YWx1ZT17dGl0bGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGl0bGUoZS50YXJnZXQudmFsdWUpfSAvPjwvZGl2PlxuICAgICAgICA8ZGl2PjxsYWJlbD5hdXRob3I6PC9sYWJlbD48aW5wdXQgZGF0YS10ZXN0aWQ9J2F1dGhvcicgdHlwZT1cInRleHRcIiB2YWx1ZT17YXV0aG9yfSBvbkNoYW5nZT17KGUpID0+IHNldEF1dGhvcihlLnRhcmdldC52YWx1ZSl9IC8+PC9kaXY+XG4gICAgICAgIDxkaXY+PGxhYmVsPnVybDo8L2xhYmVsPjxpbnB1dCBkYXRhLXRlc3RpZD0ndXJsJyB0eXBlPVwidGV4dFwiIHZhbHVlPXt1cmx9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXJsKGUudGFyZ2V0LnZhbHVlKX0gLz48L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPSdzdWJtaXQnPmNyZWF0ZTwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApXG59XG5cbkFkZEJsb2cucHJvcFR5cGVzID0ge1xuICBzdWJtaXROZXdCbG9nOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFkZEJsb2ciXSwiZmlsZSI6IkM6L1VzZXJzL2p2aGFyL0Z1bGxTdGFja09wZW4vb3NhNS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9BZGRCbG9nLmpzeCJ9