import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6f716b03"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6f716b03"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Blog from "/src/components/Blog.jsx?t=1729780543583";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import AddBlog from "/src/components/AddBlog.jsx";
import Togglable from "/src/components/Togglable.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [message, setMessage] = useState(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      console.log(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      setMessage("wrong credentials");
      setTimeout(() => {
        setMessage(null);
      }, 2e3);
    }
  };
  const logOut = () => {
    console.log("log out");
    window.localStorage.removeItem("loggedBlogappUser");
    setUser(null);
  };
  const submitNewBlog = async (newBlog) => {
    console.log("lol");
    const sentBlog = await blogService.create(newBlog);
    sentBlog.user = user;
    setMessage(`a new blog ${sentBlog.title} by ${sentBlog.author}`);
    setTimeout(() => {
      setMessage(null);
    }, 2e3);
    console.log(sentBlog);
    setBlogs(blogs.concat(sentBlog));
  };
  const updateBlogs = async (updatedBlog, id) => {
    const updatedLikes = await blogService.update(id, updatedBlog);
    console.log(updatedLikes);
    updatedLikes.user = updatedBlog.user;
    const updatedBlogs = blogs.map((b) => b.id === updatedLikes.id ? updatedLikes : b);
    setBlogs(updatedBlogs);
  };
  const deleteBlog = async (id) => {
    const deletedBlog = await blogService.deleteBlog(id);
    console.log(deletedBlog);
    const newBlogs = blogs.filter((b) => b.id !== id);
    setBlogs(newBlogs);
    console.log(blogs);
  };
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { children: message }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 78,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 79,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          "username ",
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: username, name: "Username", onChange: ({
            target
          }) => setUsername(target.value) }, void 0, false, {
            fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
            lineNumber: 82,
            columnNumber: 22
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
          lineNumber: 81,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          "password",
          " ",
          /* @__PURE__ */ jsxDEV("input", { type: "password", name: "Password", value: password, onChange: ({
            target
          }) => setPassword(target.value) }, void 0, false, {
            fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
            lineNumber: 88,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
          lineNumber: 86,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
          lineNumber: 92,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 80,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 77,
      columnNumber: 12
    }, this);
  } else {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { children: message }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 97,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 98,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        user.username,
        " logged in",
        /* @__PURE__ */ jsxDEV("button", { onClick: logOut, children: "log out" }, void 0, false, {
          fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
          lineNumber: 100,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 99,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "new blog", children: /* @__PURE__ */ jsxDEV(AddBlog, { submitNewBlog }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 103,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 102,
        columnNumber: 9
      }, this),
      blogs.sort((a, b) => b.likes - a.likes).map((blog) => /* @__PURE__ */ jsxDEV(Blog, { user, blog, updateBlogs, deleteBlog }, blog.id, false, {
        fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 105,
        columnNumber: 62
      }, this))
    ] }, void 0, true, {
      fileName: "C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 96,
      columnNumber: 12
    }, this);
  }
};
_s(App, "mDFvVlF3NCkoSkIPf1sVNseaNn4=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jvhar/FullStackOpen/osa5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkZROzs7Ozs7Ozs7Ozs7Ozs7OztBQTNGUixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxNQUFNQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEIsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlWLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNXLFNBQVNDLFVBQVUsSUFBSVosU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ2EsVUFBVUMsV0FBVyxJQUFJZCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDZSxVQUFVQyxXQUFXLElBQUloQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDaUIsTUFBTUMsT0FBTyxJQUFJbEIsU0FBUyxJQUFJO0FBR3JDQyxZQUFVLE1BQU07QUFDZEUsZ0JBQVlnQixPQUFPLEVBQUVDLEtBQU1YLFlBQVVDLFNBQVNELE1BQUssQ0FBQztBQUFBLEVBQ3RELEdBQUcsRUFBRTtBQUdMUixZQUFVLE1BQU07QUFDZCxVQUFNb0IsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTUosUUFBT1EsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q0gsY0FBUUQsS0FBSTtBQUNaZCxrQkFBWXdCLFNBQVNWLE1BQUtXLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUMsY0FBYyxPQUFPQyxNQUFNO0FBQy9CQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUk7QUFDRixZQUFNZCxRQUFPLE1BQU1iLGFBQWE0QixNQUFNO0FBQUEsUUFBRW5CO0FBQUFBLFFBQVVFO0FBQUFBLE1BQVMsQ0FBQztBQUM1RE8sYUFBT0MsYUFBYVUsUUFDbEIscUJBQXFCUixLQUFLUyxVQUFVakIsS0FBSSxDQUMxQztBQUNBZCxrQkFBWXdCLFNBQVNWLE1BQUtXLEtBQUs7QUFDL0JWLGNBQVFELEtBQUk7QUFDWmtCLGNBQVFDLElBQUluQixLQUFJO0FBQ2hCSCxrQkFBWSxFQUFFO0FBQ2RFLGtCQUFZLEVBQUU7QUFBQSxJQUVoQixTQUFTcUIsV0FBVztBQUNsQnpCLGlCQUFXLG1CQUFtQjtBQUM5QjBCLGlCQUFXLE1BQU07QUFDZjFCLG1CQUFXLElBQUk7QUFBQSxNQUNqQixHQUFHLEdBQUk7QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUdBLFFBQU0yQixTQUFTQSxNQUFNO0FBQ25CSixZQUFRQyxJQUFJLFNBQVM7QUFDckJkLFdBQU9DLGFBQWFpQixXQUFXLG1CQUFtQjtBQUNsRHRCLFlBQVEsSUFBSTtBQUFBLEVBQ2Q7QUFFQSxRQUFNdUIsZ0JBQWdCLE9BQU9DLFlBQVk7QUFDdkNQLFlBQVFDLElBQUksS0FBSztBQUNqQixVQUFNTyxXQUFXLE1BQU14QyxZQUFZeUMsT0FBT0YsT0FBTztBQUNqREMsYUFBUzFCLE9BQU9BO0FBQ2hCTCxlQUFZLGNBQWErQixTQUFTRSxLQUFNLE9BQU1GLFNBQVNHLE1BQU8sRUFBQztBQUMvRFIsZUFBVyxNQUFNO0FBQ2YxQixpQkFBVyxJQUFJO0FBQUEsSUFDakIsR0FBRyxHQUFJO0FBRVB1QixZQUFRQyxJQUFJTyxRQUFRO0FBRXBCakMsYUFBU0QsTUFBTXNDLE9BQU9KLFFBQVEsQ0FBQztBQUFBLEVBRWpDO0FBRUEsUUFBTUssY0FBYyxPQUFPQyxhQUFhQyxPQUFPO0FBQzdDLFVBQU1DLGVBQWUsTUFBTWhELFlBQVlpRCxPQUFPRixJQUFJRCxXQUFXO0FBQzdEZCxZQUFRQyxJQUFJZSxZQUFZO0FBQ3hCQSxpQkFBYWxDLE9BQU9nQyxZQUFZaEM7QUFDaEMsVUFBTW9DLGVBQWU1QyxNQUFNNkMsSUFBSUMsT0FBS0EsRUFBRUwsT0FBT0MsYUFBYUQsS0FBS0MsZUFBZUksQ0FBQztBQUMvRTdDLGFBQVMyQyxZQUFZO0FBQUEsRUFDdkI7QUFFQSxRQUFNRyxhQUFhLE9BQU1OLE9BQU07QUFDN0IsVUFBTU8sY0FBYyxNQUFNdEQsWUFBWXFELFdBQVdOLEVBQUU7QUFDbkRmLFlBQVFDLElBQUlxQixXQUFXO0FBQ3ZCLFVBQU1DLFdBQVdqRCxNQUFNa0QsT0FBT0osT0FBS0EsRUFBRUwsT0FBT0EsRUFBRTtBQUM5Q3hDLGFBQVNnRCxRQUFRO0FBQ2pCdkIsWUFBUUMsSUFBSTNCLEtBQUs7QUFBQSxFQUNuQjtBQUVBLE1BQUlRLFNBQVMsTUFBTTtBQUNqQixXQUNFLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxTQUFLTixxQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWM7QUFBQSxNQUNkLHVCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLFVBQUssVUFBVWtCLGFBQ2Q7QUFBQSwrQkFBQyxTQUFHO0FBQUE7QUFBQSxVQUNPLHVCQUFDLFdBQ1IsTUFBSyxRQUNMLE9BQU9oQixVQUNQLE1BQUssWUFDTCxVQUFVLENBQUM7QUFBQSxZQUFFK0M7QUFBQUEsVUFBTyxNQUFNOUMsWUFBWThDLE9BQU9DLEtBQUssS0FKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJNkM7QUFBQSxhQUx4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFVBQ087QUFBQSxVQUNULHVCQUFDLFdBQ0MsTUFBSyxZQUNMLE1BQUssWUFDTCxPQUFPOUMsVUFDUCxVQUFVLENBQUM7QUFBQSxZQUFFNkM7QUFBQUEsVUFBTyxNQUFNNUMsWUFBWTRDLE9BQU9DLEtBQUssS0FKcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJc0Q7QUFBQSxhQU54RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsV0FsQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsRUFFSixPQUVLO0FBQ0gsV0FDRSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsU0FBS2xELHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYztBQUFBLE1BQ2QsdUJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVM7QUFBQSxNQUNULHVCQUFDLFNBQUtNO0FBQUFBLGFBQUtKO0FBQUFBLFFBQVM7QUFBQSxRQUNsQix1QkFBQyxZQUFPLFNBQVMwQixRQUFRLHVCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsV0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxhQUFVLGFBQVksWUFDckIsaUNBQUMsV0FBUSxpQkFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0M5QixNQUFNcUQsS0FBSyxDQUFDQyxHQUFHUixNQUFNQSxFQUFFUyxRQUFRRCxFQUFFQyxLQUFLLEVBQUVWLElBQUtXLFVBQzVDLHVCQUFDLFFBQW1CLE1BQVksTUFBWSxhQUEwQixjQUEzREEsS0FBS2YsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RixDQUM5RjtBQUFBLFNBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsRUFFSjtBQUNGO0FBQUMxQyxHQS9IS0QsS0FBRztBQUFBMkQsS0FBSDNEO0FBaUlOLGVBQWVBO0FBQUcsSUFBQTJEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkJsb2ciLCJibG9nU2VydmljZSIsImxvZ2luU2VydmljZSIsIkFkZEJsb2ciLCJUb2dnbGFibGUiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJtZXNzYWdlIiwic2V0TWVzc2FnZSIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwidXNlciIsInNldFVzZXIiLCJnZXRBbGwiLCJ0aGVuIiwibG9nZ2VkVXNlckpTT04iLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImhhbmRsZUxvZ2luIiwiZSIsInByZXZlbnREZWZhdWx0IiwibG9naW4iLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiY29uc29sZSIsImxvZyIsImV4Y2VwdGlvbiIsInNldFRpbWVvdXQiLCJsb2dPdXQiLCJyZW1vdmVJdGVtIiwic3VibWl0TmV3QmxvZyIsIm5ld0Jsb2ciLCJzZW50QmxvZyIsImNyZWF0ZSIsInRpdGxlIiwiYXV0aG9yIiwiY29uY2F0IiwidXBkYXRlQmxvZ3MiLCJ1cGRhdGVkQmxvZyIsImlkIiwidXBkYXRlZExpa2VzIiwidXBkYXRlIiwidXBkYXRlZEJsb2dzIiwibWFwIiwiYiIsImRlbGV0ZUJsb2ciLCJkZWxldGVkQmxvZyIsIm5ld0Jsb2dzIiwiZmlsdGVyIiwidGFyZ2V0IiwidmFsdWUiLCJzb3J0IiwiYSIsImxpa2VzIiwiYmxvZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuaW1wb3J0IEFkZEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0FkZEJsb2cnXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcblxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYmxvZ1NlcnZpY2UuZ2V0QWxsKCkudGhlbigoYmxvZ3MpID0+IHNldEJsb2dzKGJsb2dzKSlcbiAgfSwgW10pXG5cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvZ2dlZFVzZXJKU09OID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRCbG9nYXBwVXNlcicpXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2dnZWRVc2VySlNPTilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgfVxuICB9LCBbXSlcblxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oeyB1c2VybmFtZSwgcGFzc3dvcmQgfSlcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcbiAgICAgICAgJ2xvZ2dlZEJsb2dhcHBVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcilcbiAgICAgIClcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBjb25zb2xlLmxvZyh1c2VyKVxuICAgICAgc2V0VXNlcm5hbWUoJycpXG4gICAgICBzZXRQYXNzd29yZCgnJylcblxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgc2V0TWVzc2FnZSgnd3JvbmcgY3JlZGVudGlhbHMnKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldE1lc3NhZ2UobnVsbClcbiAgICAgIH0sIDIwMDApXG4gICAgfVxuICB9XG5cblxuICBjb25zdCBsb2dPdXQgPSAoKSA9PiB7XG4gICAgY29uc29sZS5sb2coJ2xvZyBvdXQnKVxuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxuICAgIHNldFVzZXIobnVsbClcbiAgfVxuXG4gIGNvbnN0IHN1Ym1pdE5ld0Jsb2cgPSBhc3luYyAobmV3QmxvZykgPT4ge1xuICAgIGNvbnNvbGUubG9nKCdsb2wnKVxuICAgIGNvbnN0IHNlbnRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UuY3JlYXRlKG5ld0Jsb2cpXG4gICAgc2VudEJsb2cudXNlciA9IHVzZXJcbiAgICBzZXRNZXNzYWdlKGBhIG5ldyBibG9nICR7c2VudEJsb2cudGl0bGV9IGJ5ICR7c2VudEJsb2cuYXV0aG9yfWApXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRNZXNzYWdlKG51bGwpXG4gICAgfSwgMjAwMClcblxuICAgIGNvbnNvbGUubG9nKHNlbnRCbG9nKVxuXG4gICAgc2V0QmxvZ3MoYmxvZ3MuY29uY2F0KHNlbnRCbG9nKSlcblxuICB9XG5cbiAgY29uc3QgdXBkYXRlQmxvZ3MgPSBhc3luYyAodXBkYXRlZEJsb2csIGlkKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZExpa2VzID0gYXdhaXQgYmxvZ1NlcnZpY2UudXBkYXRlKGlkLCB1cGRhdGVkQmxvZylcbiAgICBjb25zb2xlLmxvZyh1cGRhdGVkTGlrZXMpXG4gICAgdXBkYXRlZExpa2VzLnVzZXIgPSB1cGRhdGVkQmxvZy51c2VyXG4gICAgY29uc3QgdXBkYXRlZEJsb2dzID0gYmxvZ3MubWFwKGIgPT4gYi5pZCA9PT0gdXBkYXRlZExpa2VzLmlkID8gdXBkYXRlZExpa2VzIDogYilcbiAgICBzZXRCbG9ncyh1cGRhdGVkQmxvZ3MpXG4gIH1cblxuICBjb25zdCBkZWxldGVCbG9nID0gYXN5bmMgaWQgPT4ge1xuICAgIGNvbnN0IGRlbGV0ZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UuZGVsZXRlQmxvZyhpZClcbiAgICBjb25zb2xlLmxvZyhkZWxldGVkQmxvZylcbiAgICBjb25zdCBuZXdCbG9ncyA9IGJsb2dzLmZpbHRlcihiID0+IGIuaWQgIT09IGlkKVxuICAgIHNldEJsb2dzKG5ld0Jsb2dzKVxuICAgIGNvbnNvbGUubG9nKGJsb2dzKVxuICB9XG5cbiAgaWYgKHVzZXIgPT09IG51bGwpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdj5cbiAgICAgICAgPGRpdj57bWVzc2FnZX08L2Rpdj5cbiAgICAgICAgPGgyPkxvZyBpbiB0byBhcHBsaWNhdGlvbjwvaDI+XG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIHVzZXJuYW1lIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cbiAgICAgICAgICAgICAgbmFtZT1cIlVzZXJuYW1lXCJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVc2VybmFtZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgcGFzc3dvcmR7JyAnfVxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIG5hbWU9XCJQYXNzd29yZFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9J3N1Ym1pdCc+bG9naW48L2J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG5cbiAgZWxzZSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXY+XG4gICAgICAgIDxkaXY+e21lc3NhZ2V9PC9kaXY+XG4gICAgICAgIDxoMj5ibG9nczwvaDI+XG4gICAgICAgIDxkaXY+e3VzZXIudXNlcm5hbWV9IGxvZ2dlZCBpblxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17bG9nT3V0fT5sb2cgb3V0PC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8VG9nZ2xhYmxlIGJ1dHRvbkxhYmVsPVwibmV3IGJsb2dcIj5cbiAgICAgICAgICA8QWRkQmxvZyBzdWJtaXROZXdCbG9nPXtzdWJtaXROZXdCbG9nfSAvPlxuICAgICAgICA8L1RvZ2dsYWJsZT5cbiAgICAgICAge2Jsb2dzLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKS5tYXAoKGJsb2cpID0+IChcbiAgICAgICAgICA8QmxvZyBrZXk9e2Jsb2cuaWR9IHVzZXI9e3VzZXJ9IGJsb2c9e2Jsb2d9IHVwZGF0ZUJsb2dzPXt1cGRhdGVCbG9nc30gZGVsZXRlQmxvZz17ZGVsZXRlQmxvZ30gLz5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwXG4iXSwiZmlsZSI6IkM6L1VzZXJzL2p2aGFyL0Z1bGxTdGFja09wZW4vb3NhNS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvQXBwLmpzeCJ9